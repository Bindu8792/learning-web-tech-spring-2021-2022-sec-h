<?php require('../Models/usermodel.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sign up</title>

	<link rel="icon" href="download.jpg" type="image/gif/png/jpg">
<style media="screen">
	div{
		border: 2px solid black;
		width: 500px;
		padding: 20px;
		margin-left: 400px;
		margin-top: 40px;


	}
	#firstname,#lastname,#email,#password{
		width: 300px;
		padding: 5px;
		margin-top: 5px;
		border-radius: 300px;
	}

	label{
		font-weight: bold;
		font-size: 20px;
	}
	#signup{
		width: 150px;
		padding: 6px;
		font-size: 15px;
		font-weight: bold;
		background-color:blue;
		color: white;
		border-radius: 30px;
		border-color: 1px solid black;
	}



</style>

</head>
<body>
	<div>
		<form class="" action="signup.php" method="post">
			<label for="">Firstname</label><br>
			<input id="firstname" type="text" name="Firstname" value="" placeholder="Enter your First name" required ><br><br>

			<label for="">Lastname</label><br>
			<input id="lastname" type="text" name="Lastname" value="" placeholder="Enter your Last name" required ><br><br>

			<label for="">Email</label><br>
			<input id="email" type="Email" name="Email" value="" placeholder="Enter your Email" required ><br><br>

			<label for="">password</label><br>
			<input id="password" type="password" name="password" value="" placeholder="Set your password" required ><br><br>
			
			<input id="signup" type="submit" name="signup" value="Signup">  <br>
			<p>Already a user?<a href="signin.php"><b>Sign in</b></a></p>


		</form>
	</div>


</body>
</html>